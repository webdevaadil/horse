import React from 'react'
import { ProfileNav } from './ProfileNav'

export const Profile = () => {
  return (<>
      <div style={{display:"flex"}}>
        <ProfileNav/>
            <div class="box_two">
          <h2 class="pro_heading">Profile Photo</h2>

          <div class="pic_flex_box">
            <img  src={process.env.PUBLIC_URL + "img/Rectangle1322.png"}alt="rec" />
            <button class="big_btn">Upload Photo</button>
          </div>
          <h2 class="per_text">Personal Details</h2>
          <input class="name" type="text" placeholder="Full name" />
          <div class="input_flex_box">
            <input class="dob" type="date" placeholder="Date of Birth" />
            <input class="gender" type="text" placeholder="Gender(Optinal)" />
          </div>
          <div class="button_flex_box">
            <button class="dis_btn">Discard</button>
            <button class="sav_btn">Save</button>
          </div>
        </div>
    </div>
  </>
  )
}
